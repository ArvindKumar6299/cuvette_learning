const person = {
    name:"John",
    age:30
}

const {name,age} = person;
console.log(name,age);

const message = `${name} will be ${age} in december`;
console.log(message);