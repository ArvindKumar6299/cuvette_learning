

const Map = ({number})=>{

    return(
        <div>
          <h2>{number} is My folio no</h2>
        </div>
    )
}
export default Map;