import Parent from "./Parent";


const Child = ({name,des,newParentname})=>{

    return(
        
        <h3>I am {des},{newParentname} and my name is {name}</h3>

        
    )
}

export default Child;