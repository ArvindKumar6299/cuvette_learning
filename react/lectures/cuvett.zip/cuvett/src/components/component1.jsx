import React from "react"


function component1(){


    return(
        <>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odio obcaecati neque iure accusantium asperiores doloribus vero labore nesciunt! Nemo necessitatibus a maxime quos explicabo debitis cumque saepe deleniti blanditiis! Ab.</p>
        </>
    )
}

export default component1;