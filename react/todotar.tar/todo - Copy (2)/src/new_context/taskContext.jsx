const { createContext } = require("react");


export const taskContext = createContext();

export  const TasksDispatchContext = createContext();